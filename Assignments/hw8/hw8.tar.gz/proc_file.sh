#!/bin/sh
python3 proc_file.py $@
